package com.callcompass.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.location.*;
import android.net.Uri;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity implements LocationListener {
  static final int REQ=1001;
  final List<P> base=new ArrayList<>(), auto=new ArrayList<>(), shown=new ArrayList<>();
  LinearLayout list; TextView loc, scan, stars, count; EditText search;
  LocationManager lm; double lat,lon; boolean has=false, recommend=true; int radius=5;

  @Override public void onCreate(Bundle b){ super.onCreate(b); seed(); ui(); lm=(LocationManager)getSystemService(LOCATION_SERVICE); requestLoc(); }

  void ui(){
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(5,5,7));
    LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(d(18),d(10),d(18),d(8)); top.setBackgroundColor(Color.rgb(18,17,22));
    top.addView(t("콜나침반",27,true,Color.WHITE),new LinearLayout.LayoutParams(0,d(56),1));
    TextView v=t("v0.2",13,true,Color.rgb(174,255,0)); v.setGravity(Gravity.CENTER); top.addView(v,new LinearLayout.LayoutParams(d(58),d(42))); root.addView(top);

    search=new EditText(this); search.setHint("콜지 검색"); search.setHintTextColor(Color.rgb(145,145,145)); search.setTextColor(Color.BLACK); search.setTextSize(17); search.setSingleLine(true); search.setPadding(d(18),0,d(14),0); search.setBackground(rr(Color.WHITE,14));
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,d(56)); sp.setMargins(d(16),d(14),d(16),d(8)); root.addView(search,sp);
    search.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int a,int c,int x){} public void onTextChanged(CharSequence s,int a,int b,int c){ render(); } public void afterTextChanged(Editable e){} });

    LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(d(16),d(8),d(16),d(8));
    LinearLayout lr=new LinearLayout(this); lr.setGravity(Gravity.CENTER_VERTICAL); loc=t("📍 위치 확인 중...",16,true,Color.WHITE); lr.addView(loc,new LinearLayout.LayoutParams(0,-2,1));
    Button refresh=btn("새로고침",Color.rgb(93,24,205)); refresh.setOnClickListener(vw->{ requestLoc(); if(has) discover(); }); lr.addView(refresh,new LinearLayout.LayoutParams(d(104),d(42))); info.addView(lr);
    scan=t("GPS와 주변 상권을 확인하고 있어요.",12,false,Color.rgb(155,155,160)); scan.setPadding(0,d(3),0,d(5)); info.addView(scan);
    LinearLayout ar=new LinearLayout(this); ar.setGravity(Gravity.CENTER_VERTICAL); ar.addView(t("현재 지역 매력도",14,false,Color.rgb(180,180,185)),new LinearLayout.LayoutParams(0,-2,1)); stars=t("☆☆☆☆☆",25,false,Color.rgb(174,255,0)); ar.addView(stars); info.addView(ar); root.addView(info);

    LinearLayout controls=new LinearLayout(this); controls.setPadding(d(14),d(4),d(14),d(7));
    for(int x:new int[]{3,5,10}){ Button b1=btn(x+"km",Color.rgb(48,48,54)); final int r=x; b1.setOnClickListener(vw->{radius=r; render(); if(has) discover();}); controls.addView(b1,new LinearLayout.LayoutParams(0,d(44),1)); }
    Button sort=btn("추천순",Color.rgb(93,24,205)); sort.setOnClickListener(vw->{recommend=!recommend; sort.setText(recommend?"추천순":"거리순"); render();}); LinearLayout.LayoutParams srt=new LinearLayout.LayoutParams(d(92),d(44)); srt.setMargins(d(7),0,0,0); controls.addView(sort,srt); root.addView(controls);

    LinearLayout head=new LinearLayout(this); head.setPadding(d(14),d(9),d(14),d(9)); head.setBackgroundColor(Color.rgb(35,35,38));
    head.addView(t("거리",13,true,Color.LTGRAY),new LinearLayout.LayoutParams(d(92),-2)); head.addView(t("콜포인트",13,true,Color.LTGRAY),new LinearLayout.LayoutParams(0,-2,1)); head.addView(t("콜타입",13,true,Color.LTGRAY),new LinearLayout.LayoutParams(d(128),-2)); root.addView(head);
    count=t("GPS 위치를 기다리는 중",12,false,Color.rgb(145,145,150)); count.setPadding(d(16),d(6),d(16),d(4)); root.addView(count);

    ScrollView sv=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    Button map=btn("콜포인트 지도",Color.rgb(174,255,0)); map.setTextColor(Color.rgb(28,28,32)); map.setTextSize(19); map.setOnClickListener(vw->map()); root.addView(map,new LinearLayout.LayoutParams(-1,d(66)));
    setContentView(root);
  }

  void requestLoc(){ if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ); return;} findLoc(); }
  void findLoc(){ try{ scan.setText("GPS 위치를 찾는 중..."); Location l=null; if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){ l=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,1800,5,this);} if(l==null&&lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){ l=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1800,5,this);} if(l!=null) use(l); }catch(Exception e){scan.setText("GPS를 사용할 수 없습니다.");} }
  @Override public void onLocationChanged(Location l){ use(l); }
  void use(Location l){ lat=l.getLatitude(); lon=l.getLongitude(); has=true; loc.setText(String.format(Locale.KOREA,"📍 %.5f, %.5f",lat,lon)); render(); reverse(); discover(); try{lm.removeUpdates(this);}catch(Exception e){} }
  void reverse(){ new Thread(()->{ try{ List<Address> a=new Geocoder(this,Locale.KOREA).getFromLocation(lat,lon,1); if(a!=null&&!a.isEmpty()){ Address x=a.get(0); String s=""; if(x.getAdminArea()!=null)s+=x.getAdminArea(); if(x.getLocality()!=null)s+=" "+x.getLocality(); if(x.getSubLocality()!=null)s+=" "+x.getSubLocality(); if(x.getThoroughfare()!=null)s+=" "+x.getThoroughfare(); final String z=s.trim(); runOnUiThread(()->loc.setText("📍 "+z)); } }catch(Exception e){} }).start(); }

  void discover(){ if(!has)return; scan.setText("공개 지도에서 주변 상권 후보 찾는 중..."); final int m=Math.min(radius,5)*1000;
    new Thread(()->{ try{
      String q="[out:json][timeout:18];("+
        "nwr(around:"+m+","+lat+","+lon+")[\"amenity\"~\"restaurant|bar|pub|cafe|nightclub\"];"+
        "nwr(around:"+m+","+lat+","+lon+")[\"tourism\"~\"hotel|motel\"];);out center tags 220;";
      URL u=new URL("https://overpass-api.de/api/interpreter?data="+URLEncoder.encode(q,"UTF-8")); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","CallCompass/0.2");
      BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream())); StringBuilder js=new StringBuilder(); String line; while((line=br.readLine())!=null)js.append(line); br.close();
      List<P> f=clusters(new JSONObject(js.toString())); runOnUiThread(()->{auto.clear();auto.addAll(f);scan.setText("주변 상권 후보 "+f.size()+"곳 탐색 · 기본DB와 함께 표시");render();});
    }catch(Exception e){runOnUiThread(()->scan.setText("자동 상권 탐색 일시 실패 · 기본 콜지 DB로 표시"));} }).start();
  }

  List<P> clusters(JSONObject o)throws Exception{ JSONArray es=o.getJSONArray("elements"); Map<String,C> map=new HashMap<>();
    for(int i=0;i<es.length();i++){ JSONObject e=es.getJSONObject(i),ce=e.optJSONObject("center"); double a=e.has("lat")?e.optDouble("lat"):(ce!=null?ce.optDouble("lat"):0), b=e.has("lon")?e.optDouble("lon"):(ce!=null?ce.optDouble("lon"):0); if(a==0||b==0)continue; JSONObject g=e.optJSONObject("tags"); String name=g==null?"":g.optString("name",""), am=g==null?"":g.optString("amenity",""), to=g==null?"":g.optString("tourism",""); int w=(am.equals("bar")||am.equals("pub")||am.equals("nightclub"))?5:am.equals("restaurant")?3:(to.equals("hotel")||to.equals("motel"))?4:1; String k=Math.round(a/0.0032)+":"+Math.round(b/0.0032); C x=map.get(k); if(x==null){x=new C();map.put(k,x);} x.n++;x.w+=w;x.a+=a;x.b+=b;if(!name.isEmpty()&&x.names.size()<2)x.names.add(name); }
    List<P> out=new ArrayList<>(); int n=1; for(C c:map.values()){ if(c.n<3)continue; double a=c.a/c.n,b=c.b/c.n; int sc=Math.min(95,55+c.n*2+c.w); String name=c.names.size()>1?c.names.get(0)+" · "+c.names.get(1)+" 주변":c.names.size()==1?c.names.get(0)+" 주변":"주변 상권 후보 "+n++; String grade=c.w>=22?"HOT":c.w>=14?"A":c.w>=8?"B":"스팟"; out.add(new P(name,a,b,sc,grade,"자동 탐색 상권","근거리/중거리/장거리","초저녁/저녁/심야",true)); }
    Collections.sort(out,(x,y)->Integer.compare(y.score,x.score)); return out.size()>18?new ArrayList<>(out.subList(0,18)):out; }

  void render(){ list.removeAllViews(); shown.clear(); if(!has){ TextView z=t("위치를 받으면 주변 콜지가 표시됩니다.",15,false,Color.LTGRAY); z.setPadding(d(18),d(20),d(18),d(20)); list.addView(z); return; }
    String q=search.getText().toString().trim().toLowerCase(Locale.KOREA); List<P> all=new ArrayList<>(); all.addAll(base); all.addAll(auto);
    for(P p:all){ double km=dist(lat,lon,p.lat,p.lon); if(km>radius)continue; String blob=(p.name+" "+p.area+" "+p.type+" "+p.time).toLowerCase(Locale.KOREA); if(!q.isEmpty()&&!blob.contains(q))continue; shown.add(new R(p,km,nowScore(p,km))); }
    Collections.sort(shown,recommend?(x,y)->Integer.compare(y.s,x.s):Comparator.comparingDouble(x->x.km)); count.setText("반경 "+radius+"km · "+shown.size()+"곳 · "+(recommend?"추천순":"거리순")); updateStars();
    if(shown.isEmpty()){TextView z=t("반경 안에 콜지가 없어. 10km로 넓히거나 새로고침해봐.",14,false,Color.LTGRAY);z.setPadding(d(18),d(20),d(18),d(20));list.addView(z);return;} for(int i=0;i<Math.min(60,shown.size());i++)row(shown.get(i)); }

  int nowScore(P p,double km){ int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY),ta=(h>=18&&h<21)?7:(h>=21||h<1)?13:(h>=1&&h<3)?5:-10; return Math.max(0,Math.min(100,p.score+ta+(p.dynamic?-2:3)-(int)Math.min(28,km*2.3))); }
  void updateStars(){ if(shown.isEmpty()){stars.setText("☆☆☆☆☆");return;} int n=Math.min(4,shown.size()),sum=0; for(int i=0;i<n;i++)sum+=shown.get(i).s; int a=sum/n, k=a>=90?5:a>=80?4:a>=68?3:a>=55?2:1; StringBuilder s=new StringBuilder(); for(int i=0;i<5;i++)s.append(i<k?"★":"☆"); stars.setText(s.toString()); }

  void row(R r){ P p=r.p; LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(d(12),d(9),d(10),d(9));
    LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER_HORIZONTAL); TextView km=t(String.format(Locale.KOREA,"%.1fkm",r.km),17,true,Color.WHITE);km.setGravity(Gravity.CENTER);l.addView(km); TextView badge=t(p.grade,14,true,Color.WHITE);badge.setGravity(Gravity.CENTER);badge.setBackground(rr(badgeColor(p.grade),8));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(d(78),d(31));bp.setMargins(0,d(4),0,0);l.addView(badge,bp);row.addView(l,new LinearLayout.LayoutParams(d(96),-2));
    LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.addView(t(p.name,18,true,Color.WHITE));TextView ar=t(p.area,13,false,Color.rgb(170,170,175));ar.setSingleLine(true);c.addView(ar);row.addView(c,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout rr=new LinearLayout(this);rr.setOrientation(LinearLayout.VERTICAL);rr.addView(t(p.type,12,false,Color.rgb(205,65,225)));rr.addView(t(p.time,12,false,Color.rgb(45,160,255)));row.addView(rr,new LinearLayout.LayoutParams(d(132),-2)); row.setOnClickListener(v->detail(r)); list.addView(row); View line=new View(this);line.setBackgroundColor(Color.rgb(31,31,34));list.addView(line,new LinearLayout.LayoutParams(-1,d(1))); }

  void detail(R r){ P p=r.p; String src=p.dynamic?"공개 지도 자동 탐색 후보":"기본 콜지 DB"; new AlertDialog.Builder(this).setTitle(p.name).setMessage("거리  "+String.format(Locale.KOREA,"%.1fkm",r.km)+"\n추천점수  "+r.s+"점\n등급  "+p.grade+"\n콜타입  "+p.type+"\n시간대  "+p.time+"\n출처  "+src+"\n\n※ 자동 후보와 점수는 실제 콜 발생을 보장하지 않는 참고정보야.").setNegativeButton("닫기",null).setPositiveButton("지도",(d,w)->open(p)).show(); }
  void open(P p){ try{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+p.lat+","+p.lon+"("+Uri.encode(p.name)+")"))); }catch(Exception e){Toast.makeText(this,"지도 앱을 열 수 없어.",Toast.LENGTH_SHORT).show();} }

  void map(){ if(!has)return; WebView w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.setWebViewClient(new WebViewClient());StringBuilder ms=new StringBuilder();for(int i=0;i<Math.min(30,shown.size());i++){R r=shown.get(i);String n=r.p.name.replace("'","").replace("\"","");ms.append("L.marker([").append(r.p.lat).append(",").append(r.p.lon).append("]).addTo(map).bindPopup('").append(n).append("<br>").append(String.format(Locale.US,"%.1fkm",r.km)).append(" · ").append(r.s).append("점');");}
    String h="<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'><style>html,body,#map{height:100%;margin:0}</style></head><body><div id='map'></div><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script><script>var map=L.map('map').setView(["+lat+","+lon+"],14);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);L.circleMarker(["+lat+","+lon+"],{radius:9,color:'#aaff00',fillColor:'#aaff00',fillOpacity:1}).addTo(map).bindPopup('현재 위치');"+ms+"</script></body></html>"; w.loadDataWithBaseURL("https://localhost/",h,"text/html","UTF-8",null); AlertDialog dlg=new AlertDialog.Builder(this).setTitle("콜포인트 지도").setView(w).setNegativeButton("닫기",null).create();dlg.show(); }

  void seed(){
    add("강남역",37.4979,127.0276,94,"HOT","서울 강남구 역삼동","근거리/중거리/장거리","저녁/심야"); add("건대입구",37.5404,127.0692,92,"A","서울 광진구 화양동","근거리/중거리/장거리","저녁/심야"); add("홍대입구",37.5572,126.9245,94,"HOT","서울 마포구 서교동","근거리/중거리/장거리","저녁/심야"); add("영등포역",37.5155,126.9076,91,"A","서울 영등포구 영등포동","근거리/중거리/장거리","초저녁/저녁/심야"); add("마곡나루",37.5669,126.8274,89,"A","서울 강서구 마곡동","중거리/장거리","초저녁/저녁"); add("발산역",37.5586,126.8377,91,"A","서울 강서구 발산동","근거리/중거리/장거리","저녁/심야"); add("신림역",37.4842,126.9297,90,"A","서울 관악구 신림동","근거리/중거리","저녁/심야"); add("잠실새내",37.5110,127.0859,90,"A","서울 송파구 잠실동","근거리/중거리/장거리","저녁/심야");
    add("인계동 나혜석거리",37.2631,127.0324,95,"HOT","경기 수원시 팔달구 인계동","근거리/중거리/장거리","초저녁/저녁/심야"); add("수원시청역 상권",37.2619,127.0307,93,"HOT","경기 수원시 팔달구 인계동","근거리/중거리/장거리","저녁/심야"); add("아주대 먹자골목",37.2798,127.0435,91,"A","경기 수원시 영통구 원천동","근거리/중거리/장거리","저녁/심야"); add("수원역 로데오",37.2662,127.0008,92,"A","경기 수원시 팔달구 매산로","근거리/중거리/장거리","저녁/심야"); add("수원통닭거리",37.2825,127.0188,87,"B","경기 수원시 팔달구 남수동","근거리/중거리","초저녁/저녁"); add("행궁동 카페거리",37.2837,127.0168,84,"스팟","경기 수원시 팔달구 행궁동","근거리/중거리","초저녁/저녁"); add("영통 중심상가",37.2511,127.0710,91,"A","경기 수원시 영통구 영통동","근거리/중거리/장거리","초저녁/저녁/심야"); add("망포역 상권",37.2458,127.0574,87,"B","경기 수원시 영통구 망포동","근거리/중거리","저녁/심야"); add("광교중앙역 상권",37.2886,127.0518,89,"A","경기 수원시 영통구 이의동","근거리/중거리/장거리","초저녁/저녁"); add("광교 카페거리",37.2867,127.0630,83,"스팟","경기 수원시 영통구 이의동","근거리/중거리","초저녁/저녁"); add("권선동 상권",37.2570,127.0270,82,"B","경기 수원시 권선구 권선동","근거리/중거리","저녁"); add("매탄동 상권",37.2650,127.0470,81,"동네","경기 수원시 영통구 매탄동","근거리/중거리","초저녁/저녁"); add("정자동 중심상권",37.3012,127.0108,82,"B","경기 수원시 장안구 정자동","근거리/중거리","초저녁/저녁"); add("화서역 상권",37.2837,126.9897,80,"동네","경기 수원시 팔달구 화서동","근거리/중거리","초저녁/저녁");
    add("범계역",37.3900,126.9507,91,"A","경기 안양시 동안구 호계동","근거리/중거리/장거리","저녁/심야"); add("안양1번가",37.4010,126.9228,88,"B","경기 안양시 만안구 안양동","근거리/중거리","저녁/심야"); add("야탑역",37.4113,127.1288,90,"A","경기 성남시 분당구 야탑동","근거리/중거리/장거리","저녁/심야"); add("서현역",37.3850,127.1231,90,"A","경기 성남시 분당구 서현동","근거리/중거리/장거리","저녁/심야"); add("정자역",37.3650,127.1081,87,"B","경기 성남시 분당구 정자동","근거리/중거리/장거리","초저녁/저녁"); add("경안동 중심상권",37.4095,127.2580,85,"B","경기 광주시 경안동","근거리/중거리/장거리","저녁/심야"); add("미사역 상권",37.5609,127.1935,87,"B","경기 하남시 망월동","근거리/중거리/장거리","초저녁/저녁"); add("부천 상동",37.5055,126.7530,90,"A","경기 부천시 원미구 상동","근거리/중거리/장거리","저녁/심야"); add("일산 라페스타",37.6604,126.7690,90,"A","경기 고양시 일산동구 장항동","근거리/중거리/장거리","저녁/심야"); add("김포 구래동",37.6444,126.6288,87,"B","경기 김포시 구래동","중거리/장거리","저녁/심야"); add("동탄 북광장",37.2059,127.0712,91,"A","경기 화성시 반송동","근거리/중거리/장거리","저녁/심야"); add("평택 소사벌",36.9904,127.1127,93,"HOT","경기 평택시 비전동","중거리/장거리","저녁/심야"); add("평택 고덕신도시",37.0430,127.0475,89,"A","경기 평택시 고덕동","중거리/장거리","초저녁/저녁/심야");
    add("구월동 로데오",37.4497,126.7029,94,"HOT","인천 남동구 구월동","근거리/중거리/장거리","저녁/심야"); add("부평 문화의거리",37.4895,126.7245,92,"A","인천 부평구 부평동","근거리/중거리/장거리","저녁/심야"); add("송도 센트럴파크",37.3925,126.6390,88,"B","인천 연수구 송도동","중거리/장거리","초저녁/저녁"); add("청라 커낼웨이",37.5324,126.6522,87,"B","인천 서구 청라동","중거리/장거리","저녁/심야");
  }
  void add(String n,double a,double b,int s,String g,String area,String type,String time){base.add(new P(n,a,b,s,g,area,type,time,false));}
  double dist(double a,double b,double c,double e){float[] r=new float[1];Location.distanceBetween(a,b,c,e,r);return r[0]/1000.0;}
  int badgeColor(String g){return g.equals("HOT")?Color.rgb(235,40,40):g.equals("A")?Color.rgb(236,125,0):g.equals("B")?Color.rgb(255,190,0):g.equals("동네")?Color.rgb(35,125,170):Color.rgb(34,105,160);}
  TextView t(String s,int z,boolean b,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(null,Typeface.BOLD);return v;}
  Button btn(String s,int color){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setPadding(d(4),0,d(4),0);b.setBackground(rr(color,12));return b;}
  GradientDrawable rr(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(d(r));return g;}
  int d(int x){return (int)(x*getResources().getDisplayMetrics().density);}
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)findLoc();else Toast.makeText(this,"주변 콜지를 찾으려면 위치 권한이 필요해.",Toast.LENGTH_LONG).show();}

  static class C{int n,w;double a,b;List<String> names=new ArrayList<>();}
  static class P{String name,grade,area,type,time;double lat,lon;int score;boolean dynamic;P(String n,double a,double b,int s,String g,String ar,String ty,String ti,boolean d){name=n;lat=a;lon=b;score=s;grade=g;area=ar;type=ty;time=ti;dynamic=d;}}
  static class R{P p;double km;int s;R(P p,double k,int s){this.p=p;km=k;this.s=s;}}
}
